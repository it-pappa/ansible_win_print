## Information and usage

### Label printers and paper size
Label printers can be tough, but when using "default" as label size, you will get the default labelsize for the driver.

### Tower / AWX
These modules are tested and is working fine with tower/AWX surveys


### Note!
Canon UFR drivers have 'auto' under color as default. This can not be changed with ansible or powershell. 
Only driver that have ether black or white as default can be changed/set with this module.